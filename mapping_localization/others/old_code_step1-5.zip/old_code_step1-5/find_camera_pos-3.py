'''
    File name:
    Author: Xu Liu
    Date created:
    Date last modified:
    Python Version: 2.7
'''

# read image_and_camera_id, calculate and save image position
from __future__ import (print_function, division, absolute_import)
import transforms3d as trans3d
import pickle
import cv2
import numpy as np
import sys
# x = np.genfromtxt('images.txt',dtype='str')
# x = np.loadtxt('images.txt', dtype='str', comments='#', delimiter=' ', converters=None, skiprows=0, usecols=None, unpack=False, ndmin=0)
image_id = []
points = []
frame_name = []
# read image and points in
with open('generated_docs_this_run\\image_and_camera_id.txt') as f:
    # Image list with two lines of data per image:
    #   IMAGE_ID, QW, QX, QY, QZ, TX, TY, TZ, CAMERA_ID(use this image_id[ind][-1] to extract information we need!!!ID-1 = frame number!!!), NAME
    #   POINTS2D[] as (X, Y, POINT3D_ID)
    lines=f.readlines()
    ind = -1
    length = len(lines) - 1
    img_pos_id = np.zeros((length,4))
    img_pos_id_list = []
    img_info_arr_all = []

    for line in lines:
        # skip comments in the first four lines
        if ind >= 0:
            img_id_temp = line[-9:-5]
            img_info_arr = (np.fromstring(line, dtype=float, sep=' '))
            img_info_arr_all.append(img_info_arr.copy())
            quat_img = img_info_arr[1:5]
            rot_mat_img = trans3d.quaternions.quat2mat(quat_img)
            trans_img = img_info_arr[5:8]
            img_pos_temp = - np.dot(rot_mat_img.T, trans_img)
            img_pos_id[ind,:] = np.append(int(img_info_arr[0]),img_pos_temp)
            image_id.append(int(img_info_arr[0].copy()))
            img_pos_id_list.append(img_pos_id[ind,:].copy())
        ind += 1
    # TODO: find the start (first registered) image id, and regard it as the world origin
    image_id_arr = np.asarray(image_id)
    start_imgid = np.min(image_id_arr)
    for idx,element in enumerate(img_info_arr_all):
        if element[0] == start_imgid:
            img_info_arr_start_img = element
            start_img_corr_index = idx
            break
    quat_start_img = img_info_arr_start_img[1:5]
    rot_mat_start_img = trans3d.quaternions.quat2mat(quat_start_img)
    trans_start_img = img_info_arr_start_img[5:8]
    img_pos_temp = np.dot(rot_mat_start_img, img_pos_id_list[start_img_corr_index][1:]) + trans_start_img


    img_pos_id_list_wrt_first_frame = []
    for idx, ele_in_img_pos_id_list in enumerate(img_pos_id_list):
        img_pos_temp = np.dot(rot_mat_start_img, ele_in_img_pos_id_list[1:]) + trans_start_img
        if ele_in_img_pos_id_list[0] == 8:
            print(1)
        img_pos_id_temp = np.append(ele_in_img_pos_id_list[0], img_pos_temp)
        img_pos_id_list_wrt_first_frame.append(img_pos_id_temp.copy())
img_pos_id_list_arr = np.asarray(img_pos_id_list)
img_pos_id_list_wrt_first_frame_arr = np.asarray(img_pos_id_list_wrt_first_frame)
sort_idx = np.sort(img_pos_id_list_arr[:,0],axis=0)
sort_idx_wrt_first_frame_arr = np.sort(img_pos_id_list_wrt_first_frame_arr[:,0],axis=0)
img_pos_id_list_new = []
img_pos_id_list_wrt_first_frame_new = []
img_pos_id_new = img_pos_id.copy()

for idx in np.arange(sort_idx.shape[0]):
    for _, ele_in_img_pos_id_list in enumerate(img_pos_id_list):
        if int(ele_in_img_pos_id_list[0]) == sort_idx[idx]:
            cur_element = ele_in_img_pos_id_list.copy()
            img_pos_id_new[idx,:] = cur_element.copy()
            img_pos_id_list_new.append(cur_element.copy())

for idx in np.arange(sort_idx_wrt_first_frame_arr.shape[0]):
    for _, ele_in_img_pos_id_list_wrt_first in enumerate(img_pos_id_list_wrt_first_frame):
        if int(ele_in_img_pos_id_list_wrt_first[0]) == sort_idx_wrt_first_frame_arr[idx]:
            cur_element_wrt_first = ele_in_img_pos_id_list_wrt_first.copy()
            img_pos_id_list_wrt_first_frame_new.append(ele_in_img_pos_id_list_wrt_first.copy())
img_pos_id_wrt_first_frame_arr_new = np.asarray(img_pos_id_list_wrt_first_frame_new)

np.save('generated_docs_this_run\\img_id_position.npy',img_pos_id_new)
np.save('generated_docs_this_run\\img_id_position_wrt_first_frame.npy',img_pos_id_wrt_first_frame_arr_new)
np.savetxt('generated_docs_this_run\\img_id_position.txt',img_pos_id_list_new,fmt='%.3f',delimiter=' ', newline='\n', header='#FRAME_ID, X, Y, Z', footer='', comments='')
np.savetxt('generated_docs_this_run\\img_id_position_wrt_first_frame.txt',img_pos_id_list_wrt_first_frame_new,fmt='%.3f',delimiter=' ', newline='\n', header='#FRAME_ID, X, Y, Z', footer='', comments='')
# np.savetxt('valid_points.txt',valid_points,fmt='%.3f',delimiter=' ', newline='\n', header='', footer='')
print('over')